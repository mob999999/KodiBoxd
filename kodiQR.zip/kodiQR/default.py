import xbmc
import xbmcgui
import qrcode
import socket
from io import BytesIO

# Function to get the local IP address
def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.settimeout(0)
    try:
        # Try to connect to an external server to determine the local IP address
        s.connect(('10.254.254.254', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

# Function to create and display the QR code
def create_qr_code():
    ip = get_local_ip()
    website_url = f'http://{ip}:8080'  # Replace with the desired website URL
    
    # Create the QR code
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=10, border=4)
    qr.add_data(website_url)
    qr.make(fit=True)
    
    # Create an image from the QR code
    img = qr.make_image(fill='black', back_color='white')
    
    # Save the image in memory (as BytesIO object)
    img_buffer = BytesIO()
    img.save(img_buffer)
    img_buffer.seek(0)
    
    # Display the QR code in Kodi
    dialog = xbmcgui.Dialog()
    dialog.image(img_buffer.read())
    
# Run the script to create and display the QR code
if __name__ == '__main__':
    create_qr_code()
